#Kieran Brennan Binary Search Tree

import os
import pandas as pd

#Object for defining a node in the binary search tree
class Node:
    def __init__(self, class_id: str, class_name: str):
        self.class_id = class_id
        self.class_name = class_name
        self.left: Node = None
        self.right: Node = None

class BinarySearchTree:

    def __init__(self):
        self.root: Node = None

    #inserting values into the binary search tree
    def insert(self, class_id: str, class_name: str):
       self.root = self._insert(self.root, class_id, class_name)

    def _insert(self, node: Node, class_id: str, class_name: str):
        if node is None:
            return Node(class_id, class_name)
        if class_id < node.class_id:
            node.left = self._insert(node.left, class_id, class_name)
        else:
            node.right = self._insert(node.right, class_id, class_name)
        return node

#searching for a course in the binary search tree
    def search(self, class_id: str):
        return self._search(self.root, class_id)
    
    def _search(self, node: Node, class_id: str):
        if node is None or node.class_id == class_id:
            return node
        if class_id < node.class_id:
            return self._search(node.left, class_id)
        return self._search(node.right, class_id)

    def inorder(self) -> list[Node]:
        result: list[Node] = []
        self._inorder(self.root, result)
        return result

    def print_inorder(self):
        for node in self.inorder():
            print(f"{node.class_id}: {node.class_name}")

    def remove(self, class_id: str) -> bool:
        self.root, deleted = self._remove(self.root, class_id)
        return deleted

    def _remove(self, node: Node, class_id: str):
        if node is None:
            return None, False
        if class_id < node.class_id:
            node.left, deleted = self._remove(node.left, class_id)
            return node, deleted
        if class_id > node.class_id:
            node.right, deleted = self._remove(node.right, class_id)
            return node, deleted

        # node to delete found
        if node.left is None:
            return node.right, True
        if node.right is None:
            return node.left, True

        successor = self._min_value_node(node.right)
        node.class_id = successor.class_id
        node.class_name = successor.class_name
        node.right, _ = self._remove(node.right, successor.class_id)
        return node, True

    def _min_value_node(self, node: Node) -> Node:
        current = node
        while current.left is not None:
            current = current.left
        return current
    
    def _inorder(self, node: Node, result: list[Node]):
        if node is not None:
            self._inorder(node.left, result)
            result.append(node)
            self._inorder(node.right, result)


#Reading courses from a csv file and inserting them into the binary search tree
def read_courses(csv_file_path: str = None) -> BinarySearchTree:
    bst = BinarySearchTree()
    if csv_file_path is None:
        csv_file_path = os.path.join(os.path.dirname(__file__), 'data.csv')
    try:
        df = pd.read_csv(csv_file_path)
    except FileNotFoundError:
        print(f"CSV file not found: {csv_file_path}")
        return bst
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        return bst
    for _, row in df.iterrows():
        bst.insert(str(row['Course ID']), str(row['Course Name']))
    return bst
  
    
    
    

def menu ():
    menu_choice = 0
    bst = BinarySearchTree()
    
    while True:  
        print("1. Load courses from file and insert into binary search tree.")
        print("2. Order courses in the binary search tree.")
        print("3. Search for a course by its ID and display its details if found.")
        print("4. Remove a course by its ID from the binary search tree.")
        print("5. Exit the program")

        
        menu_choice = input("Enter your choice: ")
        try:
            menu_choice = int(menu_choice)
        except ValueError:
            print("Invalid choice. Please enter a number between 1 and 5.")
            continue

        if menu_choice < 1 or menu_choice > 5:
            print("Invalid choice. Please enter a number between 1 and 5.")
            continue
        
        match menu_choice:
            case 1:
                bst = read_courses()
                print("Courses loaded into binary search tree.")
            case 2:
                if bst.root is None:
                    print("Tree is empty. Load courses first.")
                else:
                    bst.print_inorder()
            case 3:
                if bst.root is None:
                    print("Tree is empty. Load courses first.")
                    continue
                course_id = input("Enter the course ID to search for: ")
                result = bst.search(course_id)
                if result:
                    print(f"Course found: {result.class_id} - {result.class_name}")
                else:
                    print("Course not found.")
            case 4:
                if bst.root is None:
                    print("Tree is empty. Load courses first.")
                    continue
                course_id = input("Enter the course ID to remove: ")
                removed = bst.remove(course_id)
                if removed:
                    print(f"Course removed: {course_id}")
                else:
                    print("Course not found.")
            case 5:
                print("Exiting the program...")
                exit()
                return
    
    
def main():
   menu()

    
main()




    